/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM - Open Source CRM application.
 * Copyright (C) 2014-2020 Yuri Kuznetsov, Taras Machyshyn, Oleksiy Avramenko
 * Website: https://www.espocrm.com
 *
 * EspoCRM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * EspoCRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EspoCRM. If not, see http://www.gnu.org/licenses/.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 * 
 * Control Board - Open source plug in module for EspoCRM
 * Copyright (C) 2020 Omar A Gonsenheim
************************************************************************/

define('control-board:views/dashlets/instruments/progress-cards', 'view', function (Dep) {

    return Dep.extend({
        
        template: 'control-board:instruments/progress-cards',
        
        criteriaScope: null,
        
        criteriaAttribute: null,
        
        criteriaAttributeDisplayMap: null,
        
        progressCardsList: [],
        
        dateFrom: null,
        
        dateTo: null,
        
        recordList: {},
        
        init: function () {
            // load instrument specific metadata variables
            this.criteriaScope = this.getMetadata().get(['dashlets', this.options.dashletName, 'criteriaScope']) || this.criteriaScope;
            this.criteriaAttribute = this.getMetadata().get(['dashlets', this.options.dashletName, 'criteriaAttribute']) || this.criteriaAttribute;
            this.criteriaAttributeDisplayMap = this.getMetadata().get(['dashlets', this.options.dashletName, 'criteriaAttributeDisplayMap']) || this.criteriaAttributeDisplayMap;
        },    

        url: function () {
            // generate the url parameter for the ajax call to retrieve the instrument data
            var url = 'ControlBoard/action/totalsByCriteria?scope='+this.options.scope;
            if(this.criteriaScope && this.criteriaAttribute) {
                url += '&criteriaScope=' + this.criteriaScope + '&criteriaAttribute=' + this.criteriaAttribute;            
            }       
            if (this.options.dateFilter) {
                url += '&dateFilter=' + this.options.dateFilter;                
            }
            if (this.options.dateFilter === 'between') {
                url += '&dateFrom=' + this.options.dateFrom + '&dateTo=' + this.options.dateTo;
            }
            if (this.options.primaryFilter) {
                url += '&primaryFilter=' + this.options.primaryFilter;                
            }
            url += '&instrumentName=' + this.options.dashletName;
            //console.log("control-board:views/dashlets/instruments/progress-cards url = ",url);
            return url;
        },

        fetch: function (callbackMethod) {
            //Get the information from the database, generated as follows:
            // Ajax Call > PHP Controller > PHP Service > PHP Controller > Ajax Response
            $.ajax({
                type: 'get',
                url: this.url(),
                success: function (responseData) {
                    console.log('control-board:views/dashlets/instruments/progress-cards.js fetch() response from back-end = ',responseData);                                
                    callbackMethod.call(this, responseData);
                }.bind(this)
            });
        },
        
        setup: function() {
            // hold off rendering
            this.wait(true); 
            // call method fetch() passing a callback function
            var self = this;
            this.fetch(function(responseData) {
                self.progressCardsList = self.prepareData(responseData);
                self.wait(false);
                //console.log('control-board:views/dashlets/instruments/progress-cards.js setup() self.wait disabled');                            
            });          
        },
        
        data: function() {
            //console.log('control-board:views/dashlets/instruments/progress-cards.js data() this.progressCardsList = ',this.progressCardsList);            
            return {
                dateFrom: this.dateFrom,
                dateTo: this.dateTo,
                primaryFilter: this.options.primaryFilter,
                progressCardsList: this.progressCardsList
            };
        },
        
        prepareData: function (response) {
            // 'response' is a multidimensional array,
            // the first element of "response" contains an array of objects: {categoryTotal: "2", category: "Allocated"}
            // build the progress cards list array combining the ajax response and the category display map            
            var dataTotal = 0;
            var progressCardsList = [];
            var categoryValue = '';
            var categoryTotal = '';
            var categoryMap = {};
            var categoryIcon = '';
            var categoryClass = '';
            var categoryValue = '';
            var categoryPercent = 0;      
            response[0].forEach(function (categoryData) {
                 if(!this.dateFrom) {
                    this.dateFrom = categoryData.dateFrom;
                }
                if(!this.dateTo) {
                    this.dateTo = categoryData.dateTo;
                }
                dataTotal += parseInt(categoryData.categoryTotal);  
                categoryValue = categoryData.categoryValue;
                // create a category name element for the recordList object
                this.recordList[categoryValue] = [];                
                categoryTotal = categoryData.categoryTotal; 
                categoryMap = this.criteriaAttributeDisplayMap.find(item => item.attributeLabel === categoryValue);
                if(categoryMap && categoryMap.icon && categoryMap.class) {
                    // load the display data
                    categoryIcon = categoryMap.icon;
                    categoryClass = categoryMap.class; 
                    categoryValue = categoryMap.attributeLabel;
                } else {
                    categoryIcon = '';
                    categoryClass = '';
                    categoryValue = '';
                }
                // build a card object for the category
                var cardObject = {
                  categoryValue: categoryValue,
                  categoryValue: categoryValue,
                  categoryTotal: categoryTotal,
                  categoryIcon: categoryIcon,
                  categoryClass: categoryClass
                };
                progressCardsList.push(cardObject);                      
            },this);       
            // add the categoryPercent value for each card
            progressCardsList.forEach(function (card) {
                card.categoryPercent = Math.round((parseInt(card.categoryTotal)/dataTotal)*100);               
            });
            // the second element of "response" contains an array of objects: {recordId: "(record id)", categoryValue: "Allocated"}
            //  build and load the record list by category object
            response[1].forEach(function (recordData) {
                this.recordList[recordData.categoryValue].push(recordData.recordId);
            },this);            
            //console.log('control-board:views/dashlets/instruments/progress-cards.js prepareData() this.recordList = ',this.recordList);            
            // pass the progressCardsList array to the setup function
            return progressCardsList;
        },
        
        events: {
            'click a.card-link': function(e) {
                var criteriaValue = $(e.currentTarget).data('criteriavalue');
                var dateFrom = $(e.currentTarget).data('from');
                var dateTo = $(e.currentTarget).data('to');
                var criteriaAttribute = this.criteriaAttribute;
                this.createView('recordList','control-board:views/modals/card-record-list',{                         
                    entityType: this.options.scope,
                    criteriaValue: criteriaValue,
                    recordList: this.recordList
                }, function (view) {
                    view.render();   
                    this.listenToOnce(view, 'select', function (model) {
                        this.clearView('recordList');
                        var url = '#'+model.urlRoot+'/view/'+model.id;
                        // invoke the controller to render the record selected
                        this.getRouter().dispatch(model.urlRoot, 'view', {id:model.id}); 
                        // add the single record view url to the browsing history
                        this.getRouter().navigate(url);
                    }, this);                    
                });
            }
        }        
    });
});

