<?php
/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM - Open Source CRM application.
 * Copyright (C) 2014-2020 Yuri Kuznetsov, Taras Machyshyn, Oleksiy Avramenko
 * Website: https://www.espocrm.com
 *
 * EspoCRM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * EspoCRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EspoCRM. If not, see http://www.gnu.org/licenses/.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 * 
 * Control Board - Open source plug in module for EspoCRM
 * Copyright (C) 2020 Omar A Gonsenheim
************************************************************************/

namespace Espo\Modules\ControlBoard\Services;

use \Espo\ORM\Entity;

use Espo\Core\Utils\Util;

use \Espo\Core\Exceptions\Error;
use \Espo\Core\Exceptions\Forbidden;

class ControlBoard extends \Espo\Services\Record
{

    public function totalsByCriteria($scope, $criteriaScope, $criteriaAttribute, $dateFilter, $dateFrom = null, $dateTo = null)
    {
        if ($dateFilter !== 'between' && $dateFilter !== 'ever') {
            list($dateFrom, $dateTo) = $this->getDateRangeByFilter($dateFilter);
        }
        $pdo = $this->getEntityManager()->getPDO();

        // see if the criteria options is set in metadata
        $options = $this->getMetadata()->get('entityDefs.'.$criteriaScope.'.fields.'.$criteriaAttribute.'.options', []);
        if(!$options) {
            // if the criteria options are not set in metadata, get them from the criteria table
            //TBD
        }       
        // see if the scope and criteria scope are not the same  
        if($scope !== $criteriaScope) {
            // if the criteria table is different than the scope table, get the options from the criteria table
            // TBD
        }
        $result = [];
        // build the sql command string for the criteria summary data
        $sql = 'SELECT '.Util::camelCaseToUnderscore($scope).'.id as recordId, Count('.Util::camelCaseToUnderscore($scope).'.id) As categoryTotal, ';
        $sql.= Util::camelCaseToUnderscore($criteriaScope).'.'.Util::camelCaseToUnderscore($criteriaAttribute).' As categoryName, ';   
        $sql.= '"'.$dateFrom.'" as dateFrom, "'.$dateTo.'" as dateTo ';
        $sql.= 'FROM '.Util::camelCaseToUnderscore($scope).' WHERE '.Util::camelCaseToUnderscore($scope).'.deleted <> "1" ';                
        if ($dateFilter !== 'ever') {
            $sql.= 'And created_at >= "'.$dateFrom.'" And created_at <= "'.$dateTo.'" ';
        }
        $sql.= 'GROUP BY '.Util::camelCaseToUnderscore($criteriaScope).'.'.Util::camelCaseToUnderscore($criteriaAttribute).' ';
//$GLOBALS['log']->debug(' Espo\Modules\ControlBoard\Services\ControlBoard totalsByCriteria() sql1:', [$sql]);      
        $sth = $pdo->prepare($sql);
        $sth->execute();
        $criteriaSummary = $sth->fetchAll(\PDO::FETCH_ASSOC);
        $result[] = $criteriaSummary;
        // build the sql command to retrieve the list of records included in the criteria summary data
        $sql = 'SELECT '.Util::camelCaseToUnderscore($scope).'.id as recordId, ';
        $sql.= Util::camelCaseToUnderscore($scope).'.'.Util::camelCaseToUnderscore($criteriaAttribute).' As categoryName '; 
        $sql.= 'FROM '.Util::camelCaseToUnderscore($scope).' WHERE '.Util::camelCaseToUnderscore($scope).'.deleted <> "1" ';                
        if ($dateFilter !== 'ever') {
            $sql.= 'And created_at >= "'.$dateFrom.'" And created_at <= "'.$dateTo.'" ';
        }
        $sql.= 'ORDER BY '.Util::camelCaseToUnderscore($scope).'.'.Util::camelCaseToUnderscore($criteriaAttribute).' ASC, ';
        $sql.= Util::camelCaseToUnderscore($criteriaScope).'.created_at ASC';  
//$GLOBALS['log']->debug(' Espo\Modules\ControlBoard\Services\ControlBoard totalsByCriteria() sql2:', [$sql]);      
        $sth = $pdo->prepare($sql);
        $sth->execute();
        $recordList = $sth->fetchAll(\PDO::FETCH_ASSOC);
        $result[] = $recordList;        
        return $result;
    }

    protected function getDateRangeByFilter($dateFilter)
    {
        switch ($dateFilter) {
            case 'currentYear':
                $dt = new \DateTime();
                return [
                    $dt->modify('first day of January this year')->format('Y-m-d'),
                    $dt->add(new \DateInterval('P1Y'))->format('Y-m-d')
                ];
            case 'currentQuarter':
                $dt = new \DateTime();
                $quarter = ceil($dt->format('m') / 3);
                $dt->modify('first day of January this year');
                return [
                    $dt->add(new \DateInterval('P'.(($quarter - 1) * 3).'M'))->format('Y-m-d'),
                    $dt->add(new \DateInterval('P3M'))->format('Y-m-d')
                ];
            case 'currentMonth':
                $dt = new \DateTime();
                return [
                    $dt->modify('first day of this month')->format('Y-m-d'),
                    $dt->add(new \DateInterval('P1M'))->format('Y-m-d')
                ];
            case 'currentFiscalYear':
                $dtToday = new \DateTime();
                $dt = new \DateTime();
                $fiscalYearShift = $this->getConfig()->get('fiscalYearShift', 0);
                $dt->modify('first day of January this year')->modify('+' . $fiscalYearShift . ' months');
                if (intval($dtToday->format('m')) < $fiscalYearShift + 1) {
                    $dt->modify('-1 year');
                }
                return [
                    $dt->format('Y-m-d'),
                    $dt->add(new \DateInterval('P1Y'))->format('Y-m-d')
                ];
            case 'currentFiscalQuarter':
                $dtToday = new \DateTime();
                $dt = new \DateTime();
                $fiscalYearShift = $this->getConfig()->get('fiscalYearShift', 0);
                $dt->modify('first day of January this year')->modify('+' . $fiscalYearShift . ' months');
                $month = intval($dtToday->format('m'));
                $quarterShift = floor(($month - $fiscalYearShift - 1) / 3);
                if ($quarterShift) {
                    if ($quarterShift >= 0) {
                        $dt->add(new \DateInterval('P'.($quarterShift * 3).'M'));
                    } else {
                        $quarterShift *= -1;
                        $dt->sub(new \DateInterval('P'.($quarterShift * 3).'M'));
                    }
                }
                return [
                    $dt->format('Y-m-d'),
                    $dt->add(new \DateInterval('P3M'))->format('Y-m-d')
                ];
        }
        return [0, 0];
    }
    
    public function getListDataCards($params)
    {
        $disableCount = false;
        if (
            $this->listCountQueryDisabled
            ||
            $this->getMetadata()->get(['entityDefs', $this->entityType, 'collection', 'countDisabled'])
        ) {
            $disableCount = true;
        }
        $maxSize = 0;
        if ($disableCount) {
           if (!empty($params['maxSize'])) {
               $maxSize = $params['maxSize'];
               $params['maxSize'] = $params['maxSize'] + 1;
           }
        }
        // define the fields to be fetched for display in the record data cards       
        $selectParams = $this->getSelectParams($params);
        $selectParams['maxTextColumnsLength'] = $this->getMaxSelectTextAttributeLength();
        $selectAttributeList = $this->getSelectAttributeList($params);
        if ($selectAttributeList) {
            $selectParams['select'] = $selectAttributeList;
        } else {
            $selectParams['skipTextColumns'] = $this->isSkipSelectTextAttributes();
        }
        // define the criteria specifications which will be used to group the record data cards into columns
        $controlBoardCriteriaData = $this->getMetadata()->get(['entityDefs', $this->entityType, 'controlBoardCriteriaData']);
        // define the field which contains the criteria value
        $controlBoardCriteriaField = $controlBoardCriteriaData['controlBoardCriteriaField'];
        // see if the criteria field needs to be re-calculated
        $fieldSelectStatement = $this->getMetadata()->get(['entityDefs', $this->entityType, 'fields', $controlBoardCriteriaField, 'select']);
        // if the criteria field value needs to be re-calculated, execute the query to update this field in the database
        if ($fieldSelectStatement) {
            $pdo = $this->getEntityManager()->getPDO();
            $sql = 'UPDATE '.Util::camelCaseToUnderscore($this->entityType).' SET `'.$controlBoardCriteriaField.'` = '.$fieldSelectStatement;
            $sth = $pdo->prepare($sql);
            $sth->execute();            
        }
        // initialize a collection for the entity type
        $collection = new \Espo\ORM\EntityCollection([], $this->entityType);        
        $criteriaConditionGroups = $controlBoardCriteriaData['criteriaConditionGroups'];

        $additionalData = (object) [
            'groupList' => []
        ];

        foreach ($criteriaConditionGroups as $group) {
            $selectParamsSub = $selectParams;            
            $type = $group['conditionGroupType'];
            $label = $group['conditionGroupLabel'];
            $conditionIndex = 0;
            foreach($group['conditionValues'] as $whereCondition) {
                $operator = '';
                if($whereCondition['operator'] && $whereCondition['operator'] !== '=') {
                    $operator = $whereCondition['operator'];
                } 
                $groupValue = $whereCondition['value'];
                if($whereCondition['valueType'] && $whereCondition['valueType'] === 'int') {
                    $groupValue = intval($groupValue);
                } 
                if($conditionIndex > 0 && $type === 'or') {
                    $selectParamsSub['whereClause'][] = [
                        'OR' => [$controlBoardCriteriaField.$operator => $groupValue]
                    ];                           
                } else {
                    $selectParamsSub['whereClause'][] = [
                        $controlBoardCriteriaField.$operator => $groupValue
                    ];                           
                }
                $conditionIndex++;                
            }     
            $o = (object) [
                'name' => $label
            ];
            // retrieve the collection for the criteria condition group
            $collectionSub = $this->getRepository()->find($selectParamsSub);
            if (!$disableCount) {
                $totalSub = $this->getRepository()->count($selectParamsSub);
            } else {
                if ($maxSize && count($collectionSub) > $maxSize) {
                    $totalSub = -1;
                    unset($collectionSub[count($collectionSub) - 1]);
                } else {
                    $totalSub = -2;
                }
            }
            foreach ($collectionSub as $e) {
                $this->loadAdditionalFieldsForList($e);
                if (!empty($params['loadAdditionalFields'])) {
                    $this->loadAdditionalFields($e);
                }
                if (!empty($selectAttributeList)) {
                    $this->loadLinkMultipleFieldsForList($e, $selectAttributeList);
                }
                $this->prepareEntityForOutput($e);
                $collection[] = $e;
            }
            $o->total = $totalSub;
            $o->list = $collectionSub->getValueMapList();
            $additionalData->groupList[] = $o;            
        }
        if (!$disableCount) {
            $total = $this->getRepository()->count($selectParams);
        } else {
            if ($maxSize && count($collection) > $maxSize) {
                $total = -1;
                unset($collection[count($collection) - 1]);
            } else {
                $total = -2;
            }
        }
        return (object) [
            'total' => $total,
            'collection' => $collection,
            'additionalData' => $additionalData
        ];
    }
}
